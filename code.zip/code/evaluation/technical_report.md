# Technical approach and changes

## Pipeline

The agent is deterministic Python; it makes no model/API calls. It loads request, identity history, policy, activity, and manifest CSVs; parses manifest-scoped JSON, SQL, logs, text, and PDFs; normalizes each resource observation with source/capture timestamps; resolves the request email to a stable user and historical identifiers; filters both evidence capture and observation times to `audit_at`; applies the supplied category rules; builds findings, remediation, and verification steps; then validates the CSV and JSON output.

## Fixes driven by the public evaluation

- Log extraction now handles quoted key/value records, JSON-like structured lines, bullet-prefixed pipe-format handovers, strict numeric resource IDs, and trace-scoped identity context. Correlation is carried only between events with the same trace/request key.
- SQL parsing maps generic table aliases used by primary/replica exports as well as known customer-prefixed names. SQLite processing remains isolated and accepts only table creation and inserts.
- PDF evidence associates nearby lines around a resource reference so identifiers split across document lines remain extractable. Attachment filenames map to the attachment deletion rule.
- Identity resolution excludes current snapshot values whose `updated_at` is later than the audit cutoff. Evidence files captured after cutoff are ineligible even when an internal record timestamp is older.
- Category aliases cover service log event names and collection names. Null-like text values are not counted as identifiers. Backup restore candidacy and deletion-block fields affect state; retained security records with missing expiry metadata are conservatively treated as retained.
- Exact-token matching avoids substring matches in emails, hashes, and phones. Activity can establish a resource link only if its own details contain an exact resolved identifier.
- Remediation classes remain ordered so flows and restores are handled before records. Explicit source/parent relationships order downstream records before sources within the same operation class.
- Output validation checks schema, coverage, sorting, exact step fields, allowed operation/state pairs, phase and operation-class order, reference validity, evidence capture time, and future-action evidence blanks.

## Evaluation

The public sample improved from 26/32 to 29/32 status accuracy, 1/32 to 6/32 exact rows/sequences, 19/196 to 102/195 aligned steps, and 332/1372 to 859/1365 fields. No previously passing public-sample status regressed; three became newly correct. These are the only available canonical metrics. The remaining public sample mismatches and their exact missing/extra step tuples are listed in `evaluation_report.md`.

The final full dataset run emitted 518 rows: 111 `COMPLETE`, 400 `INCOMPLETE`, and 7 `NOT_APPLICABLE`; it indexed 2,545 observations and produced 11 OCR-unavailable warnings. These counts describe pipeline output, not accuracy: the repository has no canonical labels for those 518 rows.

## Limitations

Eleven screenshots could not be OCR-read in this runtime. Some public-sample resource IDs are not directly tied to the request identity by participant-facing evidence; the implementation leaves those cases unresolved rather than joining by case numbering, names alone, reported status, or time proximity. No hidden-set accuracy or production readiness is claimed.
