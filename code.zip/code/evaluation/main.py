"""Evaluate predictions against the public sample reference only."""
import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "code"))
import main as pipeline


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def score(predicted, expected):
    p = {r["case_id"]: r for r in predicted}
    e = {r["case_id"]: r for r in expected}
    ids = sorted(set(p) | set(e))
    status_ok = sum(cid in p and cid in e and p[cid]["deletion_status"] == e[cid]["deletion_status"] for cid in ids)
    exact_rows = 0
    exact_sequences = 0
    steps_correct = 0
    steps_total = 0
    fields_correct = 0
    fields_total = 0
    mismatches = []
    fields = ("step_no", "phase", "system_id", "resource_id", "operation", "state", "evidence_id")
    for cid in ids:
        if cid not in p or cid not in e:
            mismatches.append(cid)
            continue
        ps, es = json.loads(p[cid]["steps_json"]), json.loads(e[cid]["steps_json"])
        same_seq = ps == es
        exact_sequences += int(same_seq)
        exact_rows += int(same_seq and p[cid]["deletion_status"] == e[cid]["deletion_status"])
        if not same_seq or p[cid]["deletion_status"] != e[cid]["deletion_status"]:
            mismatches.append(cid)
        max_len = max(len(ps), len(es))
        steps_total += max_len
        for i in range(max_len):
            if i < len(ps) and i < len(es):
                steps_correct += int(ps[i] == es[i])
                for field in fields:
                    fields_total += 1
                    fields_correct += int(ps[i].get(field) == es[i].get(field))
            else:
                fields_total += len(fields)
    n = max(1, len(ids))
    return {
        "cases": len(ids), "status_correct": status_ok, "status_accuracy": status_ok / n,
        "exact_row_correct": exact_rows, "exact_row_accuracy": exact_rows / n,
        "sequence_correct": exact_sequences, "sequence_accuracy": exact_sequences / n,
        "step_correct": steps_correct, "step_count_max_aligned": steps_total,
        "step_accuracy": steps_correct / max(1, steps_total),
        "field_correct": fields_correct, "field_count": fields_total,
        "field_accuracy": fields_correct / max(1, fields_total), "mismatches": mismatches,
    }


def pct(value):
    return f"{value * 100:.1f}%"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=ROOT / "dataset/sample_deletion_requests.csv")
    parser.add_argument("--expected", type=Path, default=ROOT / "dataset/sample_output.csv")
    parser.add_argument("--output", type=Path, default=ROOT / "work/sample_prediction.csv")
    parser.add_argument("--report", type=Path, default=ROOT / "code/evaluation/evaluation_report.md")
    parser.add_argument("--baseline", type=Path, default=ROOT / "work/baseline_sample_prediction.csv")
    args = parser.parse_args()
    pipeline.run(args.input, ROOT / "dataset", args.output, ROOT / "work/evaluation_run.json")
    full_run_report = ROOT / "code/evaluation/run_report.json"
    if full_run_report.exists():
        run_report = json.loads(full_run_report.read_text(encoding="utf-8"))
    else:
        run_report = {"request_count": 0, "output_count": 0, "parsed_observations": 0,
                      "manifest_count": 0, "warnings": ["No full-dataset run report found."],
                      "statuses": {"COMPLETE": 0, "INCOMPLETE": 0, "NOT_APPLICABLE": 0}}
    metrics = score(read_rows(args.output), read_rows(args.expected))
    expected_rows = {r["case_id"]: r for r in read_rows(args.expected)}
    predicted_rows = {r["case_id"]: r for r in read_rows(args.output)}
    detail_lines = []
    def step_key(step):
        return (step.get("phase"), step.get("system_id"), step.get("resource_id"), step.get("operation"), step.get("state"), step.get("evidence_id"))
    for cid in metrics["mismatches"]:
        if cid not in expected_rows or cid not in predicted_rows:
            detail_lines.append(f"- `{cid}`: missing prediction or reference row.")
            continue
        expected, predicted = expected_rows[cid], predicted_rows[cid]
        es, ps = json.loads(expected["steps_json"]), json.loads(predicted["steps_json"])
        ecount, pcount = {}, {}
        for step in es:
            ecount[step_key(step)] = ecount.get(step_key(step), 0) + 1
        for step in ps:
            pcount[step_key(step)] = pcount.get(step_key(step), 0) + 1
        missing, extra = [], []
        for key, count in ecount.items():
            missing.extend([key] * max(0, count - pcount.get(key, 0)))
        for key, count in pcount.items():
            extra.extend([key] * max(0, count - ecount.get(key, 0)))
        order_note = ""
        if ps != es and not missing and not extra:
            order_note = f"; order differs (predicted {[step_key(x) for x in ps]}, expected {[step_key(x) for x in es]})"
        detail_lines.append(f"- `{cid}` status: predicted `{predicted['deletion_status']}`, expected `{expected['deletion_status']}`; missing expected steps: {missing or 'none'}; extra/different predicted steps: {extra or 'none'}{order_note}.")
    baseline_metrics = score(read_rows(args.baseline), read_rows(args.expected)) if args.baseline.is_file() else None
    mismatch_preview = ", ".join(metrics["mismatches"]) or "None"
    baseline_text = (f"The saved pre-change run scored {baseline_metrics['status_correct']}/{baseline_metrics['cases']} status cases ({pct(baseline_metrics['status_accuracy'])}), {baseline_metrics['exact_row_correct']}/{baseline_metrics['cases']} exact rows, {baseline_metrics['sequence_correct']}/{baseline_metrics['cases']} exact sequences, {baseline_metrics['step_correct']}/{baseline_metrics['step_count_max_aligned']} aligned steps, and {baseline_metrics['field_correct']}/{baseline_metrics['field_count']} fields."
                     if baseline_metrics else "No saved baseline prediction was supplied for this evaluation run.")
    md = f"""# Evaluation report

## Public sample comparison

The evaluator compares the 32 public requests with `dataset/sample_output.csv`. This is a development check only; it is not an estimate of hidden-set performance.

| Metric | Result |
|---|---:|
| Cases | {metrics['cases']} |
| Case-level deletion-status accuracy | {metrics['status_correct']}/{metrics['cases']} ({pct(metrics['status_accuracy'])}) |
| Exact output-row accuracy (status and whole step sequence) | {metrics['exact_row_correct']}/{metrics['cases']} ({pct(metrics['exact_row_accuracy'])}) |
| Exact step-sequence accuracy | {metrics['sequence_correct']}/{metrics['cases']} ({pct(metrics['sequence_accuracy'])}) |
| Aligned step accuracy | {metrics['step_correct']}/{metrics['step_count_max_aligned']} ({pct(metrics['step_accuracy'])}) |
| Step-field accuracy | {metrics['field_correct']}/{metrics['field_count']} ({pct(metrics['field_accuracy'])}) |

The final full-dataset pipeline run processed {run_report['request_count']} requests and emitted {run_report['output_count']} rows. It indexed {run_report['parsed_observations']} observations from {run_report['manifest_count']} manifest entries. The run reported {len(run_report['warnings'])} evidence warnings; those limitations are recorded in `run_report.json`.

## Baseline and case-by-case error inventory

{baseline_text}

This inventory lists every public sample row that is not an exact match. Step tuples are `(phase, system_id, resource_id, operation, state, evidence_id)`. `missing` and `extra` are multiset differences against the public reference.

{chr(10).join(detail_lines) if detail_lines else 'No public-sample mismatches.'}

## Error categories and inspected root causes

- **Identity resolution:** exact linkage is unavailable when evidence contains an unlinked empty snapshot or an operational event that names only a resource. The pipeline does not infer identity from case numbering, names alone, or time proximity. This limits cases whose resource IDs are not joined to supplied identifiers.
- **Evidence extraction:** the earlier parser did not preserve links across trace-correlated log events, handle bullet-prefixed handover rows, normalize quoted values, distinguish service names from resource IDs, recognize generic SQL replica table names, or connect identifiers split across PDF lines. These formats are now parsed and covered by regressions.
- **Temporal reasoning:** the previous filter checked record timestamps but not evidence-file capture timestamps, and a future current-identity snapshot could be added after resolving a historical email. Both timestamps are now enforced independently.
- **Policy evaluation:** event category aliases, literal `null` values, support attachments versus shared support messages, backup restore flags, and retained audit records with incomplete expiry metadata were not normalized consistently. These now use explicit category and rule conditions.
- **Recreation risk:** connector and backup states could be missed when the identity appeared on a sibling event in the same trace. Trace-scoped context is now carried, and `enabled`, `eligible`, and deletion-block fields are evaluated deterministically.
- **Remediation ordering:** the prior logic sorted only by operation class and lexical resource ID. Explicit source/parent references now place downstream copies before their source within an operation class; flow disabling and restore blocking remain first.
- **Output validation:** the previous validator checked row count, JSON, phase order, and evidence membership but not evidence cutoff or operation-class ordering. Those checks are now included.

These diagnoses come from inspected public evidence and regression cases. The local dataset does not contain canonical labels for the 518 evaluation requests, so the sample metrics must not be treated as full-dataset accuracy.

## Additional regression cases authored for this implementation

The 17 unit tests in `code/tests/test_main.py` cover these synthetic patterns; none use public case IDs or expected output rows:

1. French, Japanese, and Korean deletion intent.
2. Explicit non-deletion requests, including correction, marketing opt-out, and login recovery.
3. Historical email resolution and cutoff-safe identity snapshot use.
4. Observation-time and evidence-capture-time cutoff enforcement.
5. Quoted key/value log parsing and zero-row/404 state extraction.
6. Bullet-prefixed handover rows.
7. Rejecting service names as resource IDs.
8. Trace-scoped identity propagation without cross-trace leakage.
9. Generic replica-table aliases and unknown-table rejection.
10. PDF identifier extraction when fields span adjacent lines.
11. Exact email matching that rejects longer-domain substring collisions.
12. Collection category aliases and null-like PII fields.
13. Backup restore candidacy and deletion-block handling.
14. Explicit downstream-copy-before-source ordering.
15. Policy action selection from supplied rules.

These are synthetic regression tests, not scored challenge cases.

## Failures found and improvements made

- Initial intent detection missed French, Japanese, and Korean request templates. The classifier was expanded and tested against those languages while preserving explicit non-deletion checks.
- Initial SQL parsing indexed only generic table names and missed replica-specific table suffixes. The loader now safely executes only `CREATE TABLE` and `INSERT INTO` statements in an isolated in-memory SQLite database and indexes matching replica tables.
- Status and sequence accuracy remains below a reliable submission threshold. The remaining errors are mainly incomplete resource-to-subject linkage and lack of OCR for screenshots. The pipeline deliberately does not use case IDs, expected labels, or reported workflow status as shortcuts.

Mismatching public sample cases: {mismatch_preview}.

## Pipeline run counts

`COMPLETE`: {run_report['statuses']['COMPLETE']}; `INCOMPLETE`: {run_report['statuses']['INCOMPLETE']}; `NOT_APPLICABLE`: {run_report['statuses']['NOT_APPLICABLE']}.
"""
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(md, encoding="utf-8")
    print(json.dumps({"metrics": metrics, "baseline_metrics": baseline_metrics, "report": str(args.report)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
