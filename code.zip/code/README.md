# Northstar Shop deletion audit agent

This deterministic Python pipeline reads the participant-facing CSVs and the manifest-referenced evidence files, resolves current and historical identifiers, filters observations by `audit_at`, applies the deletion rules, and writes the required `output.csv` format. It does not call an external model and does not use the public expected-output file for prediction.

## Run

From the repository root with Python 3.10 or later:

```bash
python code/main.py --input dataset/deletion_requests.csv --output output.csv
```

The pipeline defaults to those paths and writes a compact diagnostic report to `code/evaluation/run_report.json`. It validates the output header, row coverage and sorting, JSON shape, step fields, allowed operations/states, phase and operation-class ordering, evidence references and cutoffs, and consecutive step numbers after writing.

Run the public sample comparison and logic tests with:

```bash
python code/evaluation/main.py
python -m unittest discover -s code/tests -v
```

`pypdf` is used for text extraction from PDFs. Install it with `python -m pip install -r code/requirements.txt`. Image screenshots are reported as unreadable when OCR is unavailable; install Tesseract and `pytesseract` to enable screenshot extraction in an environment that provides both.

## Design

- CSV loading validates required headers and tries common UTF encodings and delimiters.
- Identity resolution uses exact normalized email matches plus dated audit-log history; it never links people by name alone.
- The evidence loader follows `evidence_files.csv`, applies path containment checks, and indexes JSON, SQL, key/value and structured logs, pipe-format handovers, text, and PDFs with both observation and capture times.
- SQL imports run only approved `CREATE TABLE` and `INSERT INTO` statements in an isolated in-memory SQLite database. Other statements are ignored.
- A record is matched through stable subject IDs, current or historical emails, phones, email hashes, or resource links explicitly grounded in participant-facing evidence. Trace context is scoped to a single trace.
- Workflow activity results are not accepted as proof of a completed deletion. Dated record read-backs and snapshots drive findings and verification.
- Incomplete cases receive findings, remediation operations, and future verification steps. Future actions have an empty `evidence_id`; completed-case verification cites participant-visible evidence.
- Output ordering is deterministic, with active flows and restore risks handled before records and explicit downstream-to-source dependencies respected within an operation class.

## Limits

The supplied screenshots are not machine-read in the current runtime because the OCR Python package is unavailable. Their manifest entries are reported in the diagnostic warnings. The final run produced 518 rows (111 `COMPLETE`, 400 `INCOMPLETE`, 7 `NOT_APPLICABLE`), but these are pipeline output counts, not accuracy metrics. The public sample comparison is a development check only; there is no canonical output for the 518 evaluation requests, so their accuracy cannot be measured locally. See `evaluation/evaluation_report.md` and `evaluation/usage_report.md` for the measured public-sample results and run usage details.
